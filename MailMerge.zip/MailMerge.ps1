﻿# =====================================================================
#  Outlook Mail Merge Tool  (PowerShell - koi install nahi chahiye)
#  To, CC, BCC, Attachments ke saath Outlook se mail merge.
#  Chalane ke liye: Start_MailMerge.bat par double-click karein.
# =====================================================================

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$AppTitle = "Outlook Mail Merge"
$BaseCols = @('To', 'CC', 'BCC', 'Name', 'Attachments')
$script:CommonAtt = New-Object System.Collections.ArrayList
$script:LogRows = New-Object System.Collections.ArrayList
$script:Stop = $false

function New-BaseTable {
    $t = New-Object System.Data.DataTable
    foreach ($c in $BaseCols) { [void]$t.Columns.Add($c) }
    return , $t
}
$script:Table = New-BaseTable

# ------------------------------------------------------------ helpers
function Show-Msg($text, $icon = 'Information') {
    [void][System.Windows.Forms.MessageBox]::Show($text, $AppTitle, 'OK', $icon)
}
function Ask-YesNo($text) {
    return ([System.Windows.Forms.MessageBox]::Show($text, $AppTitle, 'YesNo', 'Question') -eq 'Yes')
}
function New-Ctl($type, $x, $y, $w, $h, $text, $parent) {
    $c = New-Object "System.Windows.Forms.$type"
    $c.Location = New-Object System.Drawing.Point($x, $y)
    $c.Size = New-Object System.Drawing.Size($w, $h)
    if ($text) { $c.Text = $text }
    $parent.Controls.Add($c)
    return $c
}
function Ensure-Column($name) {
    foreach ($col in $script:Table.Columns) {
        if ($col.ColumnName -ieq $name) { return $col.ColumnName }
    }
    [void]$script:Table.Columns.Add($name)
    return $name
}
function Update-Count {
    $lblCount.Text = "Total recipients: " + $script:Table.Rows.Count
    $names = @(); foreach ($col in $script:Table.Columns) { $names += '{' + $col.ColumnName + '}' }
    $lblPh.Text = "Placeholders: " + ($names -join '  ')
}
function Write-Log($text) {
    $txtLog.AppendText($text + "`r`n")
}
function Fill-Template([string]$t, $row) {
    foreach ($col in $script:Table.Columns) {
        $v = [string]$row[$col.ColumnName]
        $t = [regex]::Replace($t, [regex]::Escape('{' + $col.ColumnName + '}'), $v.Replace('$', '$$'), 'IgnoreCase')
    }
    return $t
}
function Join-Addr([string]$a, [string]$b) {
    $parts = @()
    foreach ($x in @($a, $b)) {
        foreach ($y in ($x -split ';')) { if ($y.Trim()) { $parts += $y.Trim() } }
    }
    return ($parts -join '; ')
}
function Get-Attachments($row) {
    $found = New-Object System.Collections.ArrayList
    $missing = New-Object System.Collections.ArrayList
    $folder = $txtFolder.Text.Trim()
    foreach ($p in ([string]$row['Attachments'] -split ';')) {
        $p = $p.Trim().Trim('"')
        if (-not $p) { continue }
        $p = Fill-Template $p $row
        if (-not [System.IO.Path]::IsPathRooted($p) -and $folder) { $p = Join-Path $folder $p }
        if (Test-Path -LiteralPath $p -PathType Leaf) { [void]$found.Add($p) } else { [void]$missing.Add($p) }
    }
    foreach ($p in $script:CommonAtt) {
        if (Test-Path -LiteralPath $p -PathType Leaf) { [void]$found.Add($p) } else { [void]$missing.Add($p) }
    }
    return @{ Found = $found; Missing = $missing }
}
function Build-Job($row) {
    $body = Fill-Template $txtBody.Text $row
    if (-not ($body -match '<[a-zA-Z/][^>]*>')) {
        $body = [System.Net.WebUtility]::HtmlEncode($body) -replace "`r?`n", '<br>'
    }
    $att = Get-Attachments $row
    return @{
        To          = ([string]$row['To']).Trim()
        CC          = Join-Addr ([string]$row['CC']) $txtCC.Text
        BCC         = Join-Addr ([string]$row['BCC']) $txtBCC.Text
        Subject     = Fill-Template $txtSubject.Text $row
        Body        = "<div style=`"font-family:Calibri,Arial;font-size:11pt`">$body</div>"
        Attachments = $att.Found
        Missing     = $att.Missing
    }
}
function Add-Records($headers, $records) {
    $map = @{}
    $hasTo = $false
    foreach ($h in $headers) { if ($h -ieq 'To') { $hasTo = $true } }
    foreach ($h in $headers) {
        if (-not $h) { continue }
        $std = $h
        foreach ($s in $BaseCols) { if ($h -ieq $s) { $std = $s } }
        if ($h -ieq 'Email' -and -not $hasTo) { $std = 'To' }
        $map[$h] = Ensure-Column $std
    }
    if (-not ($map.Values -contains 'To')) {
        Show-Msg "Pehli row me 'To' (ya 'Email') column hona zaroori hai." 'Error'
        return 0
    }
    $n = 0
    foreach ($rec in $records) {
        $dr = $script:Table.NewRow()
        foreach ($h in $map.Keys) { $dr[$map[$h]] = [string]$rec[$h] }
        if (([string]$dr['To']).Trim()) { $script:Table.Rows.Add($dr); $n++ }
    }
    return $n
}

# ------------------------------------------------------------ form
$form = New-Object System.Windows.Forms.Form
$form.Text = $AppTitle
$form.Size = New-Object System.Drawing.Size(1020, 740)
$form.MinimumSize = New-Object System.Drawing.Size(900, 660)
$form.StartPosition = 'CenterScreen'
$form.Font = New-Object System.Drawing.Font('Segoe UI', 9)

$tabs = New-Object System.Windows.Forms.TabControl
$tabs.Dock = 'Fill'
$form.Controls.Add($tabs)
$tab1 = New-Object System.Windows.Forms.TabPage; $tab1.Text = '  1. Recipients  '
$tab2 = New-Object System.Windows.Forms.TabPage; $tab2.Text = '  2. Email Content  '
$tab3 = New-Object System.Windows.Forms.TabPage; $tab3.Text = '  3. Preview & Send  '
$tabs.TabPages.AddRange(@($tab1, $tab2, $tab3))

# ===== TAB 1 : Recipients =====
$btnLoad  = New-Ctl Button 10 10 170 30 'Excel / CSV Load karein' $tab1
$btnDel   = New-Ctl Button 190 10 150 30 'Selected Row Delete' $tab1
$btnClear = New-Ctl Button 350 10 90 30 'Sab Clear' $tab1
$lblCount = New-Ctl Label 700 16 280 22 '' $tab1
$lblCount.Anchor = 'Top,Right'; $lblCount.TextAlign = 'MiddleRight'

$grp = New-Ctl GroupBox 10 48 980 140 'Manually recipient add karein' $tab1
$grp.Anchor = 'Top,Left,Right'
New-Ctl Label 10 27 60 20 'To *' $grp | Out-Null
$txtMTo = New-Ctl TextBox 75 24 380 23 '' $grp
New-Ctl Label 480 27 60 20 'CC' $grp | Out-Null
$txtMCc = New-Ctl TextBox 545 24 420 23 '' $grp
New-Ctl Label 10 58 60 20 'BCC' $grp | Out-Null
$txtMBcc = New-Ctl TextBox 75 55 380 23 '' $grp
New-Ctl Label 480 58 60 20 'Name' $grp | Out-Null
$txtMName = New-Ctl TextBox 545 55 420 23 '' $grp
New-Ctl Label 10 89 65 20 'Attachments' $grp | Out-Null
$txtMAtt = New-Ctl TextBox 75 86 760 23 '' $grp
$btnMFiles = New-Ctl Button 845 84 120 27 'Files chunein...' $grp
$lblHint = New-Ctl Label 75 114 500 20 'Multiple emails / files ko ; se alag karein' $grp
$lblHint.ForeColor = 'Gray'
$btnAdd = New-Ctl Button 845 112 120 25 '+ Add Recipient' $grp

$grid = New-Ctl DataGridView 10 196 980 470 '' $tab1
$grid.Anchor = 'Top,Bottom,Left,Right'
$grid.AllowUserToAddRows = $false
$grid.SelectionMode = 'FullRowSelect'
$grid.AutoSizeColumnsMode = 'Fill'
$grid.BackgroundColor = 'White'
$grid.DataSource = $script:Table

# ===== TAB 2 : Email content =====
New-Ctl Label 10 15 140 20 'Subject:' $tab2 | Out-Null
$txtSubject = New-Ctl TextBox 155 12 830 23 'Invoice {InvoiceNo} - {Name}' $tab2
$txtSubject.Anchor = 'Top,Left,Right'
New-Ctl Label 10 46 140 20 'Common CC (sabko):' $tab2 | Out-Null
$txtCC = New-Ctl TextBox 155 43 830 23 '' $tab2; $txtCC.Anchor = 'Top,Left,Right'
New-Ctl Label 10 77 140 20 'Common BCC (sabko):' $tab2 | Out-Null
$txtBCC = New-Ctl TextBox 155 74 830 23 '' $tab2; $txtBCC.Anchor = 'Top,Left,Right'
New-Ctl Label 10 108 140 20 'Attachments folder:' $tab2 | Out-Null
$txtFolder = New-Ctl TextBox 155 105 740 23 '' $tab2; $txtFolder.Anchor = 'Top,Left,Right'
$btnFolder = New-Ctl Button 905 103 80 27 'Browse' $tab2; $btnFolder.Anchor = 'Top,Right'
$lblF = New-Ctl Label 155 131 820 18 '(Excel me sirf file ka naam ho, jaise inv1.pdf, to is folder me dhundha jayega)' $tab2
$lblF.ForeColor = 'Gray'

$grpC = New-Ctl GroupBox 10 155 975 105 'Common attachments (har email ke saath jayenge)' $tab2
$grpC.Anchor = 'Top,Left,Right'
$lstCommon = New-Ctl ListBox 10 22 830 75 '' $grpC; $lstCommon.Anchor = 'Top,Left,Right'
$btnCAdd = New-Ctl Button 850 22 115 28 'Add files' $grpC; $btnCAdd.Anchor = 'Top,Right'
$btnCRem = New-Ctl Button 850 56 115 28 'Remove' $grpC; $btnCRem.Anchor = 'Top,Right'

$grpB = New-Ctl GroupBox 10 268 975 400 'Body  (placeholders: {Name}, {InvoiceNo} ya koi bhi column naam)' $tab2
$grpB.Anchor = 'Top,Bottom,Left,Right'
$txtBody = New-Ctl TextBox 10 22 955 340 '' $grpB
$txtBody.Multiline = $true; $txtBody.ScrollBars = 'Vertical'; $txtBody.AcceptsReturn = $true
$txtBody.Font = New-Object System.Drawing.Font('Segoe UI', 10)
$txtBody.Anchor = 'Top,Bottom,Left,Right'
$txtBody.Text = "Dear {Name},`r`n`r`nPlease find attached invoice {InvoiceNo} for amount {Amount}, due on {DueDate}.`r`n`r`nRegards,"
$lblPh = New-Ctl Label 10 368 955 22 '' $grpB
$lblPh.ForeColor = 'Gray'; $lblPh.Anchor = 'Bottom,Left,Right'

# ===== TAB 3 : Preview & Send =====
$grpM = New-Ctl GroupBox 10 10 975 105 'Mode' $tab3; $grpM.Anchor = 'Top,Left,Right'
$rbDisplay = New-Ctl RadioButton 15 22 900 24 'Preview - har mail Outlook me khulega (aap khud Send dabayenge)' $grpM
$rbDraft   = New-Ctl RadioButton 15 48 900 24 'Drafts me save karein' $grpM
$rbSend    = New-Ctl RadioButton 15 74 900 24 'Seedha Send karein' $grpM
$rbDisplay.Checked = $true

New-Ctl Label 10 128 210 20 'Har mail ke beech delay (seconds):' $tab3 | Out-Null
$numDelay = New-Ctl NumericUpDown 225 125 60 23 '' $tab3
$numDelay.Minimum = 0; $numDelay.Maximum = 60; $numDelay.Value = 2
$chkSkip = New-Ctl CheckBox 310 126 400 24 'Attachment missing ho to wo mail skip karein' $tab3
$chkSkip.Checked = $true

$btnPreview = New-Ctl Button 10 160 180 32 'Pehle record ka Preview' $tab3
$btnStart   = New-Ctl Button 200 160 180 32 'Mail Merge Start' $tab3
$btnStart.Font = New-Object System.Drawing.Font('Segoe UI', 9, [System.Drawing.FontStyle]::Bold)
$btnStop    = New-Ctl Button 390 160 90 32 'Stop' $tab3; $btnStop.Enabled = $false
$btnSaveLog = New-Ctl Button 845 160 140 32 'Log save karein' $tab3; $btnSaveLog.Anchor = 'Top,Right'

$prog = New-Ctl ProgressBar 10 202 975 20 '' $tab3; $prog.Anchor = 'Top,Left,Right'
$txtLog = New-Ctl TextBox 10 230 975 435 '' $tab3
$txtLog.Multiline = $true; $txtLog.ScrollBars = 'Vertical'; $txtLog.ReadOnly = $true
$txtLog.Font = New-Object System.Drawing.Font('Consolas', 9)
$txtLog.Anchor = 'Top,Bottom,Left,Right'

# ------------------------------------------------------------ events
$btnLoad.Add_Click({
    $ofd = New-Object System.Windows.Forms.OpenFileDialog
    $ofd.Filter = 'Excel / CSV|*.xlsx;*.xlsm;*.xls;*.csv|All files|*.*'
    if ($ofd.ShowDialog() -ne 'OK') { return }
    $p = $ofd.FileName
    $headers = @()
    $records = New-Object System.Collections.ArrayList
    $form.Cursor = 'WaitCursor'
    try {
        if ($p -like '*.csv') {
            $data = @(Import-Csv -LiteralPath $p)
            if ($data.Count -gt 0) {
                $headers = @($data[0].PSObject.Properties.Name)
                foreach ($o in $data) {
                    $h = @{}
                    foreach ($pp in $o.PSObject.Properties) { $h[$pp.Name] = [string]$pp.Value }
                    [void]$records.Add($h)
                }
            }
        }
        else {
            try { $xl = New-Object -ComObject Excel.Application }
            catch { Show-Msg "Is PC me MS Excel nahi mila.`nFile ko Excel me 'Save As > CSV' karke load karein." 'Error'; return }
            $wb = $null
            try {
                $xl.Visible = $false; $xl.DisplayAlerts = $false
                $wb = $xl.Workbooks.Open($p, 0, $true)
                $ws = $wb.Worksheets.Item(1)
                $ur = $ws.UsedRange
                [void]$ur.Columns.AutoFit()   # taaki dates '####' na dikhein
                $r0 = $ur.Row; $c0 = $ur.Column
                $nr = $ur.Rows.Count; $nc = $ur.Columns.Count
                for ($c = 0; $c -lt $nc; $c++) { $headers += ([string]$ws.Cells.Item($r0, $c0 + $c).Text).Trim() }
                for ($r = 1; $r -lt $nr; $r++) {
                    $h = @{}; $any = $false
                    for ($c = 0; $c -lt $nc; $c++) {
                        $v = ([string]$ws.Cells.Item($r0 + $r, $c0 + $c).Text).Trim()
                        if ($headers[$c]) { $h[$headers[$c]] = $v }
                        if ($v) { $any = $true }
                    }
                    if ($any) { [void]$records.Add($h) }
                }
            }
            finally {
                if ($wb) { $wb.Close($false) }
                $xl.Quit()
                [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($xl)
            }
        }
    }
    catch { Show-Msg ("File read nahi ho payi:`n" + $_.Exception.Message) 'Error'; return }
    finally { $form.Cursor = 'Default' }

    if ($headers.Count -eq 0) { Show-Msg 'File khali hai.' 'Warning'; return }
    $n = Add-Records $headers $records
    Update-Count
    if ($n -gt 0) { Show-Msg "$n recipients load ho gaye." }
})

$btnMFiles.Add_Click({
    $ofd = New-Object System.Windows.Forms.OpenFileDialog
    $ofd.Multiselect = $true
    if ($ofd.ShowDialog() -eq 'OK') {
        $joined = $ofd.FileNames -join '; '
        if ($txtMAtt.Text.Trim()) { $txtMAtt.Text = $txtMAtt.Text.Trim() + '; ' + $joined } else { $txtMAtt.Text = $joined }
    }
})

$btnAdd.Add_Click({
    $to = $txtMTo.Text.Trim()
    if (-not $to -or $to -notmatch '@') { Show-Msg "Sahi 'To' email address daalein." 'Warning'; return }
    $dr = $script:Table.NewRow()
    $dr['To'] = $to; $dr['CC'] = $txtMCc.Text.Trim(); $dr['BCC'] = $txtMBcc.Text.Trim()
    $dr['Name'] = $txtMName.Text.Trim(); $dr['Attachments'] = $txtMAtt.Text.Trim()
    $script:Table.Rows.Add($dr)
    foreach ($t in @($txtMTo, $txtMCc, $txtMBcc, $txtMName, $txtMAtt)) { $t.Text = '' }
    Update-Count
})

$btnDel.Add_Click({
    $toDel = @()
    foreach ($gr in $grid.SelectedRows) { $toDel += $gr.DataBoundItem.Row }
    foreach ($r in $toDel) { $r.Delete() }
    $script:Table.AcceptChanges()
    Update-Count
})

$btnClear.Add_Click({
    if ($script:Table.Rows.Count -gt 0 -and (Ask-YesNo 'Saare recipients hata dein?')) {
        $grid.DataSource = $null
        $script:Table = New-BaseTable
        $grid.DataSource = $script:Table
        Update-Count
    }
})

$btnFolder.Add_Click({
    $fbd = New-Object System.Windows.Forms.FolderBrowserDialog
    if ($fbd.ShowDialog() -eq 'OK') { $txtFolder.Text = $fbd.SelectedPath }
})

$btnCAdd.Add_Click({
    $ofd = New-Object System.Windows.Forms.OpenFileDialog
    $ofd.Multiselect = $true
    if ($ofd.ShowDialog() -eq 'OK') {
        foreach ($f in $ofd.FileNames) {
            if (-not $script:CommonAtt.Contains($f)) { [void]$script:CommonAtt.Add($f); [void]$lstCommon.Items.Add($f) }
        }
    }
})

$btnCRem.Add_Click({
    $i = $lstCommon.SelectedIndex
    if ($i -ge 0) { $script:CommonAtt.RemoveAt($i); $lstCommon.Items.RemoveAt($i) }
})

$btnPreview.Add_Click({
    $grid.EndEdit()
    if ($script:Table.Rows.Count -eq 0) { Show-Msg 'Pehle recipients add karein.' 'Warning'; return }
    $j = Build-Job $script:Table.Rows[0]
    $att = if ($j.Attachments.Count) { ($j.Attachments -join "`n  ") } else { '(none)' }
    $txt = "To: $($j.To)`nCC: $($j.CC)`nBCC: $($j.BCC)`nSubject: $($j.Subject)`n`nAttachments:`n  $att"
    if ($j.Missing.Count) { $txt += "`n`nMISSING FILES:`n  " + ($j.Missing -join "`n  ") }
    Show-Msg $txt
})

$btnStop.Add_Click({ $script:Stop = $true })

$btnStart.Add_Click({
    $grid.EndEdit()
    $rows = @($script:Table.Rows | Where-Object { ([string]$_['To']).Trim() })
    if ($rows.Count -eq 0) { Show-Msg 'Pehle recipients add karein.' 'Warning'; return }

    $mode = if ($rbSend.Checked) { 'send' } elseif ($rbDraft.Checked) { 'draft' } else { 'display' }
    if ($mode -eq 'send' -and -not (Ask-YesNo "$($rows.Count) emails seedha SEND honge. Continue?")) { return }
    if ($mode -eq 'display' -and $rows.Count -gt 25 -and -not (Ask-YesNo "$($rows.Count) Outlook windows khulengi. Continue?")) { return }

    try { $ol = New-Object -ComObject Outlook.Application }
    catch { Show-Msg ("Outlook start nahi hua:`n" + $_.Exception.Message) 'Error'; return }

    $script:Stop = $false
    $script:LogRows.Clear()
    $btnStart.Enabled = $false; $btnStop.Enabled = $true
    $prog.Maximum = $rows.Count; $prog.Value = 0
    Write-Log "--- Start: $($rows.Count) emails, mode = $mode ---"
    $ok = 0; $fail = 0; $skip = 0; $i = 0

    foreach ($r in $rows) {
        [System.Windows.Forms.Application]::DoEvents()
        if ($script:Stop) { Write-Log 'Stopped by user.'; break }
        $i++
        $j = Build-Job $r
        $status = ''
        try {
            if ($j.Missing.Count -gt 0 -and $chkSkip.Checked) {
                $status = 'SKIPPED (missing: ' + ($j.Missing -join '; ') + ')'
                $skip++
            }
            else {
                $m = $ol.CreateItem(0)
                $m.To = $j.To
                $m.CC = $j.CC
                $m.BCC = $j.BCC
                $m.Subject = $j.Subject
                $null = $m.GetInspector          # default signature load karta hai
                $m.HTMLBody = $j.Body + $m.HTMLBody
                foreach ($a in $j.Attachments) { [void]$m.Attachments.Add($a) }
                if ($mode -eq 'send') { $m.Send(); $status = 'SENT' }
                elseif ($mode -eq 'draft') { $m.Save(); $status = 'SAVED TO DRAFTS' }
                else { $m.Display($false); $status = 'OPENED FOR REVIEW' }
                if ($j.Missing.Count) { $status += ' (missing: ' + ($j.Missing -join '; ') + ')' }
                $ok++
            }
        }
        catch { $status = 'ERROR: ' + $_.Exception.Message; $fail++ }

        Write-Log "[$i] $($j.To)  ->  $status"
        [void]$script:LogRows.Add([pscustomobject]@{
            Time = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'); To = $j.To; CC = $j.CC; Subject = $j.Subject; Status = $status })
        $prog.Value = $i

        if ($mode -eq 'send' -and $numDelay.Value -gt 0 -and $i -lt $rows.Count) {
            $end = (Get-Date).AddSeconds([double]$numDelay.Value)
            while ((Get-Date) -lt $end -and -not $script:Stop) {
                [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 100
            }
        }
    }

    Write-Log "--- Done: $ok success, $fail failed, $skip skipped ---"
    $btnStart.Enabled = $true; $btnStop.Enabled = $false
    Show-Msg "Complete!`nSuccess: $ok`nFailed: $fail`nSkipped: $skip"
})

$btnSaveLog.Add_Click({
    if ($script:LogRows.Count -eq 0) { Show-Msg 'Abhi koi log nahi hai.'; return }
    $sfd = New-Object System.Windows.Forms.SaveFileDialog
    $sfd.Filter = 'CSV|*.csv'
    $sfd.FileName = 'mailmerge_log_' + (Get-Date -Format 'yyyyMMdd_HHmm') + '.csv'
    if ($sfd.ShowDialog() -eq 'OK') {
        $script:LogRows | Export-Csv -LiteralPath $sfd.FileName -NoTypeInformation -Encoding UTF8
        Show-Msg 'Log save ho gaya.'
    }
})

Update-Count
[void]$form.ShowDialog()
